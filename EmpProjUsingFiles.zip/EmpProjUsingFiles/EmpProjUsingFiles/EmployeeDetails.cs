﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class EmployeeDetails
    {
        public string empName, email, phno;
        public int empId, deptId;

        public void EmployeeDetailsInput()
        {
            Console.WriteLine("Enter Employee ID");
            empId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Employee Name");
            empName = Console.ReadLine();

            Console.WriteLine("Enter Employee email address");
            email = Console.ReadLine();

            Console.WriteLine("Enter Employee Phone number");
            phno = Console.ReadLine();

            Console.WriteLine("Enter Department ID");
            deptId = int.Parse(Console.ReadLine());
        }

        public void displayE()
        {
            
            Console.WriteLine(empId.ToString().PadLeft(10)+"|"+empName.PadLeft(10)+"|"+email.PadLeft(10)+"|"+phno.PadLeft(10)+"|"+deptId.ToString().PadLeft(10)+"|");
        }

        public string OutputdataE()
        {
            
            return (empId.ToString().PadLeft(10) + "|" + empName.PadLeft(10) + "|" + email.PadLeft(10) + "|" + phno.PadLeft(10) + "|" + deptId.ToString().PadLeft(10)+"|");
        }
    }
}
