﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class ProjectDetails:DeptDetails
    {
        public string projName;
        public int pId, DId, MempId;

        public  void ProjectDetailsInput()
        {
            Console.WriteLine("Enter Project ID");
            pId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Project Name");
            projName = Console.ReadLine();

            Console.WriteLine("Enter Department ID");
            DId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter handling manager Employee ID");
            MempId = int.Parse(Console.ReadLine());
        }

        public void displayP()
        {
            Console.WriteLine(pId.ToString().PadLeft(10)+"|"+projName.PadLeft(10)+"|"+DId.ToString().PadLeft(10)+"|"+MempId.ToString().PadLeft(10)+"|");
        }

        public string outputDataP()
        {
            return (pId.ToString().PadLeft(10) + "|" + projName.PadLeft(10) + "|" + DId.ToString().PadLeft(10) + "|" + MempId.ToString().PadLeft(10) + "|");
        }
    }
}
