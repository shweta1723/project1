﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            List<EmployeeDetails> emprec = new List<EmployeeDetails>();
            List<DeptDetails> dptrec = new List<DeptDetails>();
            List<ProjectDetails> projrec = new List<ProjectDetails>();
            string filename1 = @"D:\EMPFilesProj\empData.txt";
            string filename2 = @"D:\EMPFilesProj\DeptData.txt";
            string filename3 = @"D:\EMPFilesProj\ProjData.txt";
            int ch;

            do
            {
                Console.WriteLine("============================");
                Console.WriteLine("1. Insert Employee Details");
                Console.WriteLine("2. Insert Department Details");
                Console.WriteLine("3. Insert Project Details");
                Console.WriteLine("4. Display and write on Employee Details File");
                Console.WriteLine("5. Display and write on Department Details File");
                Console.WriteLine("6. Display and write Project Details File");
                Console.WriteLine("9. Exit");
                Console.WriteLine("============================");

                Console.WriteLine("Enter your Choice");
                ch = int.Parse(Console.ReadLine());
                Console.WriteLine("----------------------------");

                switch (ch)
                {
                    case 1:
                        EmployeeDetails emp = new EmployeeDetails();
                        emp.EmployeeDetailsInput();
                        emprec.Add(emp);
                        break;

                    case 2:
                        DeptDetails Dpt = new DeptDetails();
                        Dpt.DeptDetailsInput();
                        dptrec.Add(Dpt);
                        break;
                        
                    case 3:
                        ProjectDetails proj = new ProjectDetails();
                        proj.ProjectDetailsInput();
                        projrec.Add(proj);
                        break;

                    case 4:
                        string s1 = "EMPLOYEE DETAILS";
                        Console.WriteLine(s1.PadLeft(40));
                        if(emprec==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                using (StreamWriter W = new StreamWriter(filename1))
                                {
                                    foreach (EmployeeDetails e in emprec)
                                    {
                                        e.displayE();
                                        W.WriteLine(s1.PadLeft(40));
                                        W.Write(e.OutputdataE() + "\n");
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                        }
                        break;

                    case 5:
                        string s2 = "DEPARTMENT DETAILS";
                        Console.WriteLine(s2.PadLeft(25));
                        if(dptrec==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                using (StreamWriter W = new StreamWriter(filename2))
                                {
                                    foreach(DeptDetails d in dptrec)
                                    {
                                        d.displayD();
                                        W.WriteLine(s2.PadLeft(25));
                                        W.Write(d.outputDataD() + "\n");
                                    }
                                }
                            }
                            catch(Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                        }
                        break;

                    case 6:
                        string s3 = "PROJECT DETAILS";
                        Console.WriteLine(s3.PadLeft(35));
                        if(projrec==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                using(StreamWriter W= new StreamWriter(filename3))
                                {
                                    foreach(ProjectDetails p in projrec)
                                    {
                                        p.displayP();
                                        W.WriteLine(s3.PadLeft(35));
                                        W.Write(p.outputDataP());
                                    }
                                }
                            }catch(Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                        }
                        break;

                    case 9:
                        break;

                }
            } while (ch != 9);
        }
    }
}
